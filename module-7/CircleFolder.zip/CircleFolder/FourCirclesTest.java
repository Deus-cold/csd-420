// Samir Rodriguez
// Module Assignment 7.2

public class FourCirclesTest {
    public static void main(String[] args) {
        FourCircles.main(args);
    }
    
}
